USE [demo];
GO

DECLARE @OrderId INT = 1;

SELECT
    o.OrderNumber AS [Номер заказа],
    o.OrderDate AS [Дата заказа],
    p.ProductName AS [Продукция],
    oi.Quantity AS [Количество продукции],
    oi.Price AS [Цена продукции],
    oi.Quantity * oi.Price AS [Стоимость продукции],
    ISNULL(SUM(pm.Quantity * mp.Price * oi.Quantity), 0) AS [Стоимость материалов],
    oi.Quantity * oi.Price + ISNULL(SUM(pm.Quantity * mp.Price * oi.Quantity), 0) AS [Полная стоимость]
FROM dbo.Orders o
JOIN dbo.OrderItems oi ON oi.OrderId = o.OrderId
JOIN dbo.Products p ON p.ProductId = oi.ProductId
LEFT JOIN dbo.ProductMaterials pm ON pm.ProductId = p.ProductId
LEFT JOIN dbo.Materials m ON m.MaterialId = pm.MaterialId
LEFT JOIN dbo.Prices mp ON mp.MaterialId = m.MaterialId
WHERE o.OrderId = @OrderId
GROUP BY
    o.OrderNumber,
    o.OrderDate,
    p.ProductName,
    oi.Quantity,
    oi.Price
ORDER BY p.ProductName;
GO

