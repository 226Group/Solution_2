using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Validator
{
    public partial class Form1 : Form
    {
        private const string ApiAddress = "http://localhost:4444/TransferSimulator/mobilePhone";
        private const string TestCasePath = @"C:\Users\meshok\Desktop\Demoexampapka\Solution_2\6\TestCase_filled.docx";
        private static readonly XNamespace WordNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

        public Form1()
        {
            InitializeComponent();
        }

        private void getDataButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Encoding = Encoding.UTF8;
                    string json = client.DownloadString(ApiAddress);
                    phoneLabel.Text = ExtractPhone(json);
                    resultLabel.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось получить данные от эмулятора.\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void sendResultButton_Click(object sender, EventArgs e)
        {
            string phone = phoneLabel.Text.Trim();

            if (string.IsNullOrWhiteSpace(phone))
            {
                MessageBox.Show("Сначала получите данные от эмулятора.", "Нет данных", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool correctFormat = Regex.IsMatch(phone, @"^\+7\s\d{3}\s\d{3}-\d{2}-\d{2}$");
            bool onlyAllowedSymbols = Regex.IsMatch(phone, @"^[0-9+\s-]+$");
            bool isValid = correctFormat && onlyAllowedSymbols;

            string formatResult = correctFormat
                ? "Успешно"
                : "Не успешно: номер не соответствует шаблону +7 900 123-45-67";
            string symbolsResult = onlyAllowedSymbols
                ? "Успешно"
                : "Не успешно: номер содержит недопустимые символы";

            resultLabel.Text = isValid
                ? "Корректный номер телефона"
                : "Не корректный номер телефона";

            try
            {
                WriteResultToTestCase("Проверить формат номера телефона", formatResult);
                WriteResultToTestCase("Проверить отсутствие недопустимых символов", symbolsResult);
                MessageBox.Show("Результат проверки сохранен в TestCase_filled.docx.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Проверка выполнена, но сохранить результат в Word не удалось.\nЗакройте документ, если он открыт, и повторите попытку.\n" + ex.Message, "Ошибка сохранения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string ExtractPhone(string json)
        {
            Match match = Regex.Match(json, "\"value\"\\s*:\\s*\"(?<phone>[^\"]*)\"");

            if (match.Success)
            {
                return match.Groups["phone"].Value;
            }

            return json;
        }

        private void WriteResultToTestCase(string criterion, string result)
        {
            if (!File.Exists(TestCasePath))
            {
                throw new FileNotFoundException("Файл тест-кейса не найден.", TestCasePath);
            }

            using (ZipArchive archive = ZipFile.Open(TestCasePath, ZipArchiveMode.Update))
            {
                ZipArchiveEntry entry = archive.GetEntry("word/document.xml");

                if (entry == null)
                {
                    throw new InvalidOperationException("В документе Word не найден основной XML-файл.");
                }

                XDocument document;

                using (Stream stream = entry.Open())
                {
                    document = XDocument.Load(stream);
                }

                bool changed = false;

                foreach (XElement row in document.Descendants(WordNamespace + "tr"))
                {
                    string rowText = string.Concat(row.Descendants(WordNamespace + "t").Select(text => text.Value));

                    if (!rowText.Contains(criterion))
                    {
                        continue;
                    }

                    XElement resultCell = row.Elements(WordNamespace + "tc").ElementAtOrDefault(2);

                    if (resultCell == null)
                    {
                        continue;
                    }

                    ReplaceCellText(resultCell, result);
                    changed = true;
                    break;
                }

                if (!changed)
                {
                    throw new InvalidOperationException("В таблице не найдена строка: " + criterion);
                }

                entry.Delete();
                ZipArchiveEntry newEntry = archive.CreateEntry("word/document.xml");

                using (Stream stream = newEntry.Open())
                {
                    document.Save(stream);
                }
            }
        }

        private void ReplaceCellText(XElement cell, string text)
        {
            cell.Elements(WordNamespace + "p").Remove();
            cell.Add(
                new XElement(WordNamespace + "p",
                    new XElement(WordNamespace + "r",
                        new XElement(WordNamespace + "t", text))));
        }
    }
}
