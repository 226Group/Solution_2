:setvar JsonPath "C:\Users\username\Desktop\Demoexampapka\Solution\Sql\customers_unicode.json"

USE [demo];
GO

DECLARE @json NVARCHAR(MAX);

SELECT @json = BulkColumn
FROM OPENROWSET
(
    BULK N'$(JsonPath)',
    SINGLE_NCLOB
) AS source_file;

MERGE dbo.Customers AS target
USING
(
    SELECT
        id,
        [name],
        NULLIF(inn, N'') AS inn,
        addres AS [address],
        phone,
        salesman,
        buyer
    FROM OPENJSON(@json)
    WITH
    (
        id CHAR(9) '$.id',
        [name] NVARCHAR(200) '$.name',
        inn NVARCHAR(12) '$.inn',
        addres NVARCHAR(300) '$.addres',
        phone NVARCHAR(30) '$.phone',
        salesman BIT '$.salesman',
        buyer BIT '$.buyer'
    )
) AS source
ON target.CustomerId = source.id
WHEN MATCHED THEN
    UPDATE SET
        Name = source.[name],
        Inn = source.inn,
        Address = source.[address],
        Phone = source.phone,
        IsSalesman = source.salesman,
        IsBuyer = source.buyer
WHEN NOT MATCHED THEN
    INSERT (CustomerId, Name, Inn, Address, Phone, IsSalesman, IsBuyer)
    VALUES (source.id, source.[name], source.inn, source.[address], source.phone, source.salesman, source.buyer);
GO

SELECT CustomerId, Name, Inn, Address, Phone, IsSalesman, IsBuyer
FROM dbo.Customers
ORDER BY CustomerId;
GO
