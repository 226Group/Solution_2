USE [master];
GO

IF DB_ID(N'demo') IS NULL
BEGIN
    CREATE DATABASE [demo];
END
GO

USE [demo];
GO

SET QUOTED_IDENTIFIER ON;
GO

DECLARE @dropSql NVARCHAR(MAX) = N'';

SELECT @dropSql = @dropSql + N'ALTER TABLE '
    + QUOTENAME(OBJECT_SCHEMA_NAME(parent_object_id)) + N'.' + QUOTENAME(OBJECT_NAME(parent_object_id))
    + N' DROP CONSTRAINT ' + QUOTENAME(name) + N';' + CHAR(13)
FROM sys.foreign_keys;

EXEC sp_executesql @dropSql;

SET @dropSql = N'';

SELECT @dropSql = @dropSql + N'DROP TABLE '
    + QUOTENAME(TABLE_SCHEMA) + N'.' + QUOTENAME(TABLE_NAME) + N';' + CHAR(13)
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE';

EXEC sp_executesql @dropSql;
GO

IF OBJECT_ID(N'dbo.OrderItems', N'U') IS NOT NULL DROP TABLE dbo.OrderItems;
IF OBJECT_ID(N'dbo.Orders', N'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID(N'dbo.ProductMaterials', N'U') IS NOT NULL DROP TABLE dbo.ProductMaterials;
IF OBJECT_ID(N'dbo.Prices', N'U') IS NOT NULL DROP TABLE dbo.Prices;
IF OBJECT_ID(N'dbo.Products', N'U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID(N'dbo.Materials', N'U') IS NOT NULL DROP TABLE dbo.Materials;
IF OBJECT_ID(N'dbo.Customers', N'U') IS NOT NULL DROP TABLE dbo.Customers;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID(N'dbo.Roles', N'U') IS NOT NULL DROP TABLE dbo.Roles;
GO

CREATE TABLE dbo.Roles
(
    RoleId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Roles PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL CONSTRAINT UQ_Roles_RoleName UNIQUE
);
GO

CREATE TABLE dbo.Users
(
    UserId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
    Login NVARCHAR(50) NOT NULL CONSTRAINT UQ_Users_Login UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    FullName NVARCHAR(150) NOT NULL,
    RoleId INT NOT NULL,
    IsBlocked BIT NOT NULL CONSTRAINT DF_Users_IsBlocked DEFAULT (0),
    FailedAttempts INT NOT NULL CONSTRAINT DF_Users_FailedAttempts DEFAULT (0),
    CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT (SYSDATETIME()),
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES dbo.Roles(RoleId)
);
GO

CREATE TABLE dbo.Customers
(
    CustomerId CHAR(9) NOT NULL CONSTRAINT PK_Customers PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    Inn NVARCHAR(12) NULL,
    Address NVARCHAR(300) NULL,
    Phone NVARCHAR(30) NULL,
    IsSalesman BIT NOT NULL,
    IsBuyer BIT NOT NULL
);
GO

CREATE TABLE dbo.Materials
(
    MaterialId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Materials PRIMARY KEY,
    MaterialName NVARCHAR(150) NOT NULL CONSTRAINT UQ_Materials_Name UNIQUE,
    UnitName NVARCHAR(20) NOT NULL
);
GO

CREATE TABLE dbo.Products
(
    ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Products PRIMARY KEY,
    ProductName NVARCHAR(150) NOT NULL CONSTRAINT UQ_Products_Name UNIQUE,
    UnitName NVARCHAR(20) NOT NULL
);
GO

CREATE TABLE dbo.Prices
(
    PriceId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Prices PRIMARY KEY,
    ProductId INT NULL,
    MaterialId INT NULL,
    Price DECIMAL(12,2) NOT NULL CONSTRAINT CK_Prices_Price CHECK (Price >= 0),
    CONSTRAINT FK_Prices_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    CONSTRAINT FK_Prices_Materials FOREIGN KEY (MaterialId) REFERENCES dbo.Materials(MaterialId),
    CONSTRAINT CK_Prices_OneItem CHECK
    (
        (ProductId IS NOT NULL AND MaterialId IS NULL)
        OR
        (ProductId IS NULL AND MaterialId IS NOT NULL)
    )
);
GO

CREATE UNIQUE INDEX UX_Prices_ProductId
ON dbo.Prices(ProductId)
WHERE ProductId IS NOT NULL;
GO

CREATE UNIQUE INDEX UX_Prices_MaterialId
ON dbo.Prices(MaterialId)
WHERE MaterialId IS NOT NULL;
GO

CREATE TABLE dbo.ProductMaterials
(
    ProductMaterialId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductMaterials PRIMARY KEY,
    ProductId INT NOT NULL,
    MaterialId INT NOT NULL,
    Quantity DECIMAL(12,3) NOT NULL CONSTRAINT CK_ProductMaterials_Quantity CHECK (Quantity > 0),
    CONSTRAINT FK_ProductMaterials_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    CONSTRAINT FK_ProductMaterials_Materials FOREIGN KEY (MaterialId) REFERENCES dbo.Materials(MaterialId),
    CONSTRAINT UQ_ProductMaterials_Product_Material UNIQUE (ProductId, MaterialId)
);
GO

CREATE TABLE dbo.Orders
(
    OrderId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Orders PRIMARY KEY,
    OrderNumber NVARCHAR(50) NOT NULL,
    OrderDate DATE NOT NULL,
    CustomerName NVARCHAR(200) NOT NULL,
    ExecutorName NVARCHAR(200) NOT NULL
);
GO

CREATE TABLE dbo.OrderItems
(
    OrderItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItems PRIMARY KEY,
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity DECIMAL(12,3) NOT NULL CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
    UnitName NVARCHAR(20) NOT NULL,
    Price DECIMAL(12,2) NOT NULL CONSTRAINT CK_OrderItems_Price CHECK (Price >= 0),
    CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderId) REFERENCES dbo.Orders(OrderId),
    CONSTRAINT FK_OrderItems_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId)
);
GO

INSERT INTO dbo.Roles (RoleName)
VALUES (N'Администратор'), (N'Пользователь');

INSERT INTO dbo.Users (Login, Password, FullName, RoleId)
VALUES
    (N'admin', N'admin', N'Администратор системы', 1),
    (N'user', N'user', N'Пользователь системы', 2);

INSERT INTO dbo.Materials (MaterialName, UnitName)
VALUES
    (N'Говядина', N'кг'),
    (N'Молоко нормализованное', N'кг'),
    (N'Оболочка натуральная', N'шт'),
    (N'Соль', N'кг');

INSERT INTO dbo.Products (ProductName, UnitName)
VALUES
    (N'Пельмени "Из говядины" 900г.', N'шт'),
    (N'Пельмени "Сибирские" 900г.', N'шт'),
    (N'Сосиски венские 850г.', N'шт'),
    (N'Сосиски молочные 850г.', N'шт');

INSERT INTO dbo.Prices (MaterialId, Price)
SELECT m.MaterialId, v.Price
FROM (VALUES
    (N'Говядина', CAST(370.00 AS DECIMAL(12,2))),
    (N'Молоко нормализованное', CAST(34.00 AS DECIMAL(12,2))),
    (N'Оболочка натуральная', CAST(20.00 AS DECIMAL(12,2))),
    (N'Соль', CAST(60.00 AS DECIMAL(12,2)))
) AS v(MaterialName, Price)
JOIN dbo.Materials m ON m.MaterialName = v.MaterialName;

INSERT INTO dbo.Prices (ProductId, Price)
SELECT p.ProductId, v.Price
FROM (VALUES
    (N'Пельмени "Из говядины" 900г.', CAST(370.00 AS DECIMAL(12,2))),
    (N'Пельмени "Сибирские" 900г.', CAST(450.00 AS DECIMAL(12,2))),
    (N'Сосиски венские 850г.', CAST(570.00 AS DECIMAL(12,2))),
    (N'Сосиски молочные 850г.', CAST(560.00 AS DECIMAL(12,2)))
) AS v(ProductName, Price)
JOIN dbo.Products p ON p.ProductName = v.ProductName;

INSERT INTO dbo.ProductMaterials (ProductId, MaterialId, Quantity)
SELECT p.ProductId, m.MaterialId, v.Quantity
FROM (VALUES
    (N'Сосиски молочные 850г.', N'Молоко нормализованное', CAST(0.400 AS DECIMAL(12,3))),
    (N'Сосиски молочные 850г.', N'Говядина', CAST(1.000 AS DECIMAL(12,3))),
    (N'Сосиски молочные 850г.', N'Соль', CAST(0.003 AS DECIMAL(12,3))),
    (N'Сосиски молочные 850г.', N'Оболочка натуральная', CAST(0.100 AS DECIMAL(12,3)))
) AS v(ProductName, MaterialName, Quantity)
JOIN dbo.Products p ON p.ProductName = v.ProductName
JOIN dbo.Materials m ON m.MaterialName = v.MaterialName;

INSERT INTO dbo.Orders (OrderNumber, OrderDate, CustomerName, ExecutorName)
VALUES (N'2', '2025-06-06', N'ООО "Цельсий"', N'ООО "Мясной цех №1"');

INSERT INTO dbo.OrderItems (OrderId, ProductId, Quantity, UnitName, Price)
SELECT 1, p.ProductId, v.Quantity, N'шт', v.Price
FROM (VALUES
    (N'Пельмени "Сибирские" 900г.', CAST(4 AS DECIMAL(12,3)), CAST(450.00 AS DECIMAL(12,2))),
    (N'Пельмени "Из говядины" 900г.', CAST(8 AS DECIMAL(12,3)), CAST(510.00 AS DECIMAL(12,2))),
    (N'Сосиски венские 850г.', CAST(3 AS DECIMAL(12,3)), CAST(370.00 AS DECIMAL(12,2)))
) AS v(ProductName, Quantity, Price)
JOIN dbo.Products p ON p.ProductName = v.ProductName;
GO

CREATE OR ALTER VIEW dbo.v_OrderFullCost
AS
SELECT
    o.OrderId,
    o.OrderNumber,
    o.OrderDate,
    p.ProductName,
    oi.Quantity AS ProductQuantity,
    oi.Price AS ProductPrice,
    oi.Quantity * oi.Price AS ProductAmount,
    ISNULL(SUM(pm.Quantity * mp.Price * oi.Quantity), 0) AS MaterialsAmount,
    oi.Quantity * oi.Price + ISNULL(SUM(pm.Quantity * mp.Price * oi.Quantity), 0) AS FullAmount
FROM dbo.Orders o
JOIN dbo.OrderItems oi ON oi.OrderId = o.OrderId
JOIN dbo.Products p ON p.ProductId = oi.ProductId
LEFT JOIN dbo.ProductMaterials pm ON pm.ProductId = p.ProductId
LEFT JOIN dbo.Materials m ON m.MaterialId = pm.MaterialId
LEFT JOIN dbo.Prices mp ON mp.MaterialId = m.MaterialId
GROUP BY o.OrderId, o.OrderNumber, o.OrderDate, p.ProductName, oi.Quantity, oi.Price;
GO

CREATE OR ALTER PROCEDURE dbo.GetOrderFullCost
    @OrderId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        OrderNumber,
        OrderDate,
        ProductName,
        ProductQuantity,
        ProductPrice,
        ProductAmount,
        MaterialsAmount,
        FullAmount
    FROM dbo.v_OrderFullCost
    WHERE OrderId = @OrderId;
END
GO
