using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MyasnoiCeh
{
    public partial class LoginForm : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-UBCSF2U;Initial Catalog=demo;User ID=demo;Password=demo;TrustServerCertificate=True";

        public LoginForm()
        {
            InitializeComponent();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string login = loginTextBox.Text.Trim();
            string password = passwordTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Заполните поля \"Логин\" и \"Пароль\".", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable userTable = GetUser(login);

            if (userTable.Rows.Count == 0)
            {
                MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные", "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataRow userRow = userTable.Rows[0];
            int userId = Convert.ToInt32(userRow["UserId"]);
            bool isBlocked = Convert.ToBoolean(userRow["IsBlocked"]);

            if (isBlocked)
            {
                MessageBox.Show("Вы заблокированы. Обратитесь к администратору", "Доступ запрещен", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Convert.ToString(userRow["Password"]) != password)
            {
                RegisterFailedAttempt(userId, Convert.ToInt32(userRow["FailedAttempts"]));
                MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные", "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ResetFailedAttempts(userId);
            MessageBox.Show("Вы успешно авторизовались", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

            Form nextForm = Convert.ToString(userRow["RoleName"]) == "Администратор"
                ? (Form)new AdminForm()
                : new UserForm(Convert.ToString(userRow["FullName"]));

            Hide();
            nextForm.FormClosed += (closedSender, args) => Close();
            nextForm.Show();
        }

        private DataTable GetUser(string login)
        {
            const string sql =
                "SELECT u.UserId, u.Login, u.Password, u.FullName, u.IsBlocked, u.FailedAttempts, r.RoleName " +
                "FROM dbo.Users u " +
                "JOIN dbo.Roles r ON r.RoleId = u.RoleId " +
                "WHERE u.Login = @Login";

            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, ConnectionString))
            {
                adapter.SelectCommand.Parameters.Add("@Login", SqlDbType.NVarChar, 50).Value = login;
                DataTable table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }

        private void RegisterFailedAttempt(int userId, int currentAttempts)
        {
            int attempts = currentAttempts + 1;
            bool isBlocked = attempts >= 3;

            const string sql = "UPDATE dbo.Users SET FailedAttempts = @FailedAttempts, IsBlocked = @IsBlocked WHERE UserId = @UserId";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.Add("@FailedAttempts", SqlDbType.Int).Value = attempts;
                command.Parameters.Add("@IsBlocked", SqlDbType.Bit).Value = isBlocked;
                command.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private void ResetFailedAttempts(int userId)
        {
            const string sql = "UPDATE dbo.Users SET FailedAttempts = 0 WHERE UserId = @UserId";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}

