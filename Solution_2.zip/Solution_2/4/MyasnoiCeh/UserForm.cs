using System;
using System.Windows.Forms;

namespace MyasnoiCeh
{
    public partial class UserForm : Form
    {
        public UserForm()
            : this("Пользователь")
        {
        }

        public UserForm(string fullName)
        {
            InitializeComponent();
            welcomeLabel.Text = "Добро пожаловать, " + fullName;
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

