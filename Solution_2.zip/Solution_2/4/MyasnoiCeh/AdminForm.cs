using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MyasnoiCeh
{
    public partial class AdminForm : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-UBCSF2U;Initial Catalog=demo;User ID=demo;Password=demo;TrustServerCertificate=True";
        private int selectedUserId;

        public AdminForm()
        {
            InitializeComponent();
            LoadRoles();
            LoadUsers();
        }

        private void LoadUsers()
        {
            const string sql =
                "SELECT u.UserId, u.Login, u.Password, u.FullName, u.RoleId, r.RoleName, u.IsBlocked, u.FailedAttempts " +
                "FROM dbo.Users u " +
                "JOIN dbo.Roles r ON r.RoleId = u.RoleId " +
                "ORDER BY u.Login";

            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, ConnectionString))
            {
                DataTable table = new DataTable();
                adapter.Fill(table);
                usersGridView.DataSource = table;
            }

            if (usersGridView.Columns["Password"] != null)
            {
                usersGridView.Columns["Password"].Visible = false;
            }

            if (usersGridView.Columns["RoleId"] != null)
            {
                usersGridView.Columns["RoleId"].Visible = false;
            }
        }

        private void LoadRoles()
        {
            using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT RoleId, RoleName FROM dbo.Roles ORDER BY RoleName", ConnectionString))
            {
                DataTable table = new DataTable();
                adapter.Fill(table);
                roleComboBox.DataSource = table;
                roleComboBox.DisplayMember = "RoleName";
                roleComboBox.ValueMember = "RoleId";
            }
        }

        private void usersGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (usersGridView.CurrentRow == null || usersGridView.CurrentRow.DataBoundItem == null)
            {
                return;
            }

            DataRow row = ((DataRowView)usersGridView.CurrentRow.DataBoundItem).Row;
            selectedUserId = Convert.ToInt32(row["UserId"]);
            loginTextBox.Text = Convert.ToString(row["Login"]);
            passwordTextBox.Text = Convert.ToString(row["Password"]);
            fullNameTextBox.Text = Convert.ToString(row["FullName"]);
            roleComboBox.SelectedValue = Convert.ToInt32(row["RoleId"]);
            blockedCheckBox.Checked = Convert.ToBoolean(row["IsBlocked"]);
            failedAttemptsNumeric.Value = Convert.ToDecimal(row["FailedAttempts"]);
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            selectedUserId = 0;
            loginTextBox.Clear();
            passwordTextBox.Clear();
            fullNameTextBox.Clear();
            blockedCheckBox.Checked = false;
            failedAttemptsNumeric.Value = 0;

            if (roleComboBox.Items.Count > 0)
            {
                roleComboBox.SelectedIndex = 0;
            }

            loginTextBox.Focus();
        }

        private void unblockButton_Click(object sender, EventArgs e)
        {
            blockedCheckBox.Checked = false;
            failedAttemptsNumeric.Value = 0;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string login = loginTextBox.Text.Trim();
            string password = passwordTextBox.Text.Trim();
            string fullName = fullNameTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Заполните логин, пароль и ФИО.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (LoginExists(login, selectedUserId))
            {
                MessageBox.Show("Пользователь с указанным логином уже существует.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (selectedUserId == 0)
            {
                InsertUser(login, password, fullName);
            }
            else
            {
                UpdateUser(login, password, fullName);
            }

            LoadUsers();
            MessageBox.Show("Данные пользователя сохранены.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool LoginExists(string login, int exceptUserId)
        {
            const string sql = "SELECT COUNT(*) FROM dbo.Users WHERE Login = @Login AND UserId <> @UserId";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.Add("@Login", SqlDbType.NVarChar, 50).Value = login;
                command.Parameters.Add("@UserId", SqlDbType.Int).Value = exceptUserId;
                connection.Open();
                return Convert.ToInt32(command.ExecuteScalar()) > 0;
            }
        }

        private void InsertUser(string login, string password, string fullName)
        {
            const string sql =
                "INSERT INTO dbo.Users (Login, Password, FullName, RoleId, IsBlocked, FailedAttempts) " +
                "VALUES (@Login, @Password, @FullName, @RoleId, @IsBlocked, @FailedAttempts)";

            ExecuteSaveCommand(sql, login, password, fullName);
        }

        private void UpdateUser(string login, string password, string fullName)
        {
            const string sql =
                "UPDATE dbo.Users SET Login = @Login, Password = @Password, FullName = @FullName, " +
                "RoleId = @RoleId, IsBlocked = @IsBlocked, FailedAttempts = @FailedAttempts " +
                "WHERE UserId = @UserId";

            ExecuteSaveCommand(sql, login, password, fullName);
        }

        private void ExecuteSaveCommand(string sql, string login, string password, string fullName)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.Add("@Login", SqlDbType.NVarChar, 50).Value = login;
                command.Parameters.Add("@Password", SqlDbType.NVarChar, 100).Value = password;
                command.Parameters.Add("@FullName", SqlDbType.NVarChar, 150).Value = fullName;
                command.Parameters.Add("@RoleId", SqlDbType.Int).Value = Convert.ToInt32(roleComboBox.SelectedValue);
                command.Parameters.Add("@IsBlocked", SqlDbType.Bit).Value = blockedCheckBox.Checked;
                command.Parameters.Add("@FailedAttempts", SqlDbType.Int).Value = Convert.ToInt32(failedAttemptsNumeric.Value);
                command.Parameters.Add("@UserId", SqlDbType.Int).Value = selectedUserId;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}

