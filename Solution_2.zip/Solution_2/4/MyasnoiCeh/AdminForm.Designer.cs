namespace MyasnoiCeh
{
    partial class AdminForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView usersGridView;
        private System.Windows.Forms.GroupBox editorGroupBox;
        private System.Windows.Forms.Label loginLabel;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.Label fullNameLabel;
        private System.Windows.Forms.Label roleLabel;
        private System.Windows.Forms.Label failedAttemptsLabel;
        private System.Windows.Forms.TextBox loginTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.TextBox fullNameTextBox;
        private System.Windows.Forms.ComboBox roleComboBox;
        private System.Windows.Forms.CheckBox blockedCheckBox;
        private System.Windows.Forms.NumericUpDown failedAttemptsNumeric;
        private System.Windows.Forms.Button newButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button unblockButton;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.usersGridView = new System.Windows.Forms.DataGridView();
            this.editorGroupBox = new System.Windows.Forms.GroupBox();
            this.unblockButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.newButton = new System.Windows.Forms.Button();
            this.failedAttemptsNumeric = new System.Windows.Forms.NumericUpDown();
            this.blockedCheckBox = new System.Windows.Forms.CheckBox();
            this.roleComboBox = new System.Windows.Forms.ComboBox();
            this.fullNameTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.loginTextBox = new System.Windows.Forms.TextBox();
            this.failedAttemptsLabel = new System.Windows.Forms.Label();
            this.roleLabel = new System.Windows.Forms.Label();
            this.fullNameLabel = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.loginLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.usersGridView)).BeginInit();
            this.editorGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.failedAttemptsNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // usersGridView
            // 
            this.usersGridView.AllowUserToAddRows = false;
            this.usersGridView.AllowUserToDeleteRows = false;
            this.usersGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.usersGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.usersGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersGridView.Location = new System.Drawing.Point(12, 12);
            this.usersGridView.MultiSelect = false;
            this.usersGridView.Name = "usersGridView";
            this.usersGridView.ReadOnly = true;
            this.usersGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.usersGridView.Size = new System.Drawing.Size(610, 426);
            this.usersGridView.TabIndex = 0;
            this.usersGridView.SelectionChanged += new System.EventHandler(this.usersGridView_SelectionChanged);
            // 
            // editorGroupBox
            // 
            this.editorGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.editorGroupBox.Controls.Add(this.unblockButton);
            this.editorGroupBox.Controls.Add(this.saveButton);
            this.editorGroupBox.Controls.Add(this.newButton);
            this.editorGroupBox.Controls.Add(this.failedAttemptsNumeric);
            this.editorGroupBox.Controls.Add(this.blockedCheckBox);
            this.editorGroupBox.Controls.Add(this.roleComboBox);
            this.editorGroupBox.Controls.Add(this.fullNameTextBox);
            this.editorGroupBox.Controls.Add(this.passwordTextBox);
            this.editorGroupBox.Controls.Add(this.loginTextBox);
            this.editorGroupBox.Controls.Add(this.failedAttemptsLabel);
            this.editorGroupBox.Controls.Add(this.roleLabel);
            this.editorGroupBox.Controls.Add(this.fullNameLabel);
            this.editorGroupBox.Controls.Add(this.passwordLabel);
            this.editorGroupBox.Controls.Add(this.loginLabel);
            this.editorGroupBox.Location = new System.Drawing.Point(638, 12);
            this.editorGroupBox.Name = "editorGroupBox";
            this.editorGroupBox.Size = new System.Drawing.Size(300, 426);
            this.editorGroupBox.TabIndex = 1;
            this.editorGroupBox.TabStop = false;
            this.editorGroupBox.Text = "Данные пользователя";
            // 
            // unblockButton
            // 
            this.unblockButton.Location = new System.Drawing.Point(18, 305);
            this.unblockButton.Name = "unblockButton";
            this.unblockButton.Size = new System.Drawing.Size(260, 31);
            this.unblockButton.TabIndex = 13;
            this.unblockButton.Text = "Снять блокировку";
            this.unblockButton.UseVisualStyleBackColor = true;
            this.unblockButton.Click += new System.EventHandler(this.unblockButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(152, 258);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(126, 31);
            this.saveButton.TabIndex = 12;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // newButton
            // 
            this.newButton.Location = new System.Drawing.Point(18, 258);
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(126, 31);
            this.newButton.TabIndex = 11;
            this.newButton.Text = "Новый";
            this.newButton.UseVisualStyleBackColor = true;
            this.newButton.Click += new System.EventHandler(this.newButton_Click);
            // 
            // failedAttemptsNumeric
            // 
            this.failedAttemptsNumeric.Location = new System.Drawing.Point(128, 207);
            this.failedAttemptsNumeric.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.failedAttemptsNumeric.Name = "failedAttemptsNumeric";
            this.failedAttemptsNumeric.Size = new System.Drawing.Size(150, 23);
            this.failedAttemptsNumeric.TabIndex = 10;
            // 
            // blockedCheckBox
            // 
            this.blockedCheckBox.AutoSize = true;
            this.blockedCheckBox.Location = new System.Drawing.Point(128, 174);
            this.blockedCheckBox.Name = "blockedCheckBox";
            this.blockedCheckBox.Size = new System.Drawing.Size(111, 19);
            this.blockedCheckBox.TabIndex = 9;
            this.blockedCheckBox.Text = "Заблокирован";
            this.blockedCheckBox.UseVisualStyleBackColor = true;
            // 
            // roleComboBox
            // 
            this.roleComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.roleComboBox.FormattingEnabled = true;
            this.roleComboBox.Location = new System.Drawing.Point(128, 134);
            this.roleComboBox.Name = "roleComboBox";
            this.roleComboBox.Size = new System.Drawing.Size(150, 23);
            this.roleComboBox.TabIndex = 8;
            // 
            // fullNameTextBox
            // 
            this.fullNameTextBox.Location = new System.Drawing.Point(128, 98);
            this.fullNameTextBox.MaxLength = 150;
            this.fullNameTextBox.Name = "fullNameTextBox";
            this.fullNameTextBox.Size = new System.Drawing.Size(150, 23);
            this.fullNameTextBox.TabIndex = 7;
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(128, 62);
            this.passwordTextBox.MaxLength = 100;
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(150, 23);
            this.passwordTextBox.TabIndex = 6;
            // 
            // loginTextBox
            // 
            this.loginTextBox.Location = new System.Drawing.Point(128, 27);
            this.loginTextBox.MaxLength = 50;
            this.loginTextBox.Name = "loginTextBox";
            this.loginTextBox.Size = new System.Drawing.Size(150, 23);
            this.loginTextBox.TabIndex = 5;
            // 
            // failedAttemptsLabel
            // 
            this.failedAttemptsLabel.AutoSize = true;
            this.failedAttemptsLabel.Location = new System.Drawing.Point(15, 210);
            this.failedAttemptsLabel.Name = "failedAttemptsLabel";
            this.failedAttemptsLabel.Size = new System.Drawing.Size(55, 15);
            this.failedAttemptsLabel.TabIndex = 4;
            this.failedAttemptsLabel.Text = "Ошибки";
            // 
            // roleLabel
            // 
            this.roleLabel.AutoSize = true;
            this.roleLabel.Location = new System.Drawing.Point(15, 137);
            this.roleLabel.Name = "roleLabel";
            this.roleLabel.Size = new System.Drawing.Size(34, 15);
            this.roleLabel.TabIndex = 3;
            this.roleLabel.Text = "Роль";
            // 
            // fullNameLabel
            // 
            this.fullNameLabel.AutoSize = true;
            this.fullNameLabel.Location = new System.Drawing.Point(15, 101);
            this.fullNameLabel.Name = "fullNameLabel";
            this.fullNameLabel.Size = new System.Drawing.Size(35, 15);
            this.fullNameLabel.TabIndex = 2;
            this.fullNameLabel.Text = "ФИО";
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(15, 65);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(49, 15);
            this.passwordLabel.TabIndex = 1;
            this.passwordLabel.Text = "Пароль";
            // 
            // loginLabel
            // 
            this.loginLabel.AutoSize = true;
            this.loginLabel.Location = new System.Drawing.Point(15, 30);
            this.loginLabel.Name = "loginLabel";
            this.loginLabel.Size = new System.Drawing.Size(41, 15);
            this.loginLabel.TabIndex = 0;
            this.loginLabel.Text = "Логин";
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 450);
            this.Controls.Add(this.editorGroupBox);
            this.Controls.Add(this.usersGridView);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(850, 420);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ООО \"Мясной цех №1\" - администратор";
            ((System.ComponentModel.ISupportInitialize)(this.usersGridView)).EndInit();
            this.editorGroupBox.ResumeLayout(false);
            this.editorGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.failedAttemptsNumeric)).EndInit();
            this.ResumeLayout(false);
        }
    }
}

